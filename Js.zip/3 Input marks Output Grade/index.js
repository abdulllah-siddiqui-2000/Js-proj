
function compute(){


var EN = parseInt(document.getElementById("en").value)
var MA = parseInt(document.getElementById("ma").value)
var UD = parseInt(document.getElementById("ud").value)
var PH = parseInt(document.getElementById("ph").value)
var CM = parseInt(document.getElementById("cm").value)


var OBM = EN + MA + UD + PH + CM
document.getElementById("obm").innerText = OBM
var PER = OBM/500*100
document.getElementById("per").innerText=PER+"%"
if(PER>85){
    document.getElementById("grd").innerText="A*"
    document.getElementById("sts").innerText="PASS"
}
else if(PER<85 && PER>80){
    document.getElementById("grd").innerText="A"
    document.getElementById("sts").innerText="PASS"
}
else if(PER<80 && PER>75){
    document.getElementById("grd").innerText="B+"
    document.getElementById("sts").innerText="PASS"
}
else if(PER<75 && PER>70){
    document.getElementById("grd").innerText="B-"
    document.getElementById("sts").innerText="PASS"
}
else if(PER<70 && PER>65){
    document.getElementById("grd").innerText="C+"
    document.getElementById("sts").innerText="PASS"
}
else if(PER<65 && PER>60){
    document.getElementById("grd").innerText="C-"
    document.getElementById("sts").innerText="PASS"
}
else if(PER<60 && PER>50){
    document.getElementById("grd").innerText="D"
    document.getElementById("sts").innerText="PASS"
}
else if(PER<50){
    document.getElementById("grd").innerText="F"
    document.getElementById("sts").innerText="FAIL"
}

}





