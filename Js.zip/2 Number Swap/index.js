
function swap(){
    var num1 = document.getElementById("n1").value
    var num2 = document.getElementById("n2").value
    document.getElementById("n1").value = num2
    document.getElementById("n2").value = num1
    
}