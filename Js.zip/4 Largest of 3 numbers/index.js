var Large=document.getElementById("large")
var largest=0

function compute(){
    var n1 = parseInt(document.getElementById("num1").value)
    var n2 = parseInt(document.getElementById("num2").value)
    var n3 = parseInt(document.getElementById("num3").value)


    
    
    if(n1>n2 && n1>n3){
        largest=n1

    }
    else if(n2>n1 && n2>n3){
        largest=n2

    }
    else if(n3>n2 && n3>n1){
        largest=n3

    }
    Large.innerText=largest
}