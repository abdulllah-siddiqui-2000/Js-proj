let countEl = document.getElementById("count-el")
let saveEl = document.getElementById("save-el")
let count = 0
function increment(){
    count = count + 1
    countEl.innerText = count
}

function reset(){
    count=0
    countEl.textContent=0
}

function save(){
    console.log(count)

    let countstr=count+ " - "
    saveEl.textContent+=countstr 
    /* "textContent" is used here rather than "innerText" because innerText mostly
    displays human readable content like numbers, alphabets, characters. But it sometimes 
    fails to deliver "space" so text.Content is used and it delivers all that is in the tag */

}